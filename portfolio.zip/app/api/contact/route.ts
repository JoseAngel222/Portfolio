import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { name, email, message } = await request.json()

    // Aquí integrarías con un servicio de email como:
    // - Resend
    // - SendGrid
    // - Nodemailer
    // - EmailJS

    // Ejemplo con Resend (necesitarías instalar @resend/node):
    /*
    import { Resend } from 'resend'
    const resend = new Resend(process.env.RESEND_API_KEY)
    
    await resend.emails.send({
      from: 'contacto@tudominio.com',
      to: 'tu-email@gmail.com',
      subject: `Nuevo mensaje de ${name}`,
      html: `
        <h2>Nuevo mensaje desde tu portafolio</h2>
        <p><strong>Nombre:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Mensaje:</strong></p>
        <p>${message}</p>
      `
    })
    */

    // Por ahora, solo simulamos el envío
    console.log("Mensaje recibido:", { name, email, message })

    return NextResponse.json({
      success: true,
      message: "Mensaje enviado correctamente",
    })
  } catch (error) {
    console.error("Error al enviar mensaje:", error)
    return NextResponse.json({ success: false, message: "Error al enviar el mensaje" }, { status: 500 })
  }
}
